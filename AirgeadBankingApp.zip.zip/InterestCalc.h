#ifndef Project_Two_Header_Files_InterestCalc_H_
#define Project_Two_Header_Files_InterestCalc_H_
#pragma once

class InterestCalc {
public:
	InterestCalc();
	void setInitialDeposit(double t_initialDeposit);
	void setMonthlyDeposit(double t_monthlyDeposit);
	void setPercentInterest(double t_percentInterest);
	void setNumberYears(int t_numberYears);

	double getInitialDeposit();
	double getMonthlyDeposit();
	double getPercentInterest();
	int getNumberYears();

	double monthlyBalance(int t_months, double t_monthlyDeposit);
	double monthlyInterest(int t_months, double t_monthlyDeposit);
	double annualBalance(int t_numYears, double t_depositAmount);
	void showReport(double t_monthlyDep);

private:
	double initialDeposit;
	double monthlyDeposit;
	double percentInterest;
	int numberYears;
};
#endif

