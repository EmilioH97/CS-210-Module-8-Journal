#include <iostream>
#include "InterestCalc.h"
#include <vector>
#include <conio.h>
#include <iomanip>
using namespace std;

InterestCalc InitialDisplay(InterestCalc inputData) {
	double deposit;
	double monthly;
	double interest;
	int years;

	cout << "**********************************" << endl;
	cout << "********** Data Input ************" << endl;
	cout << "Initial Investment Amount: $";
	cin >> deposit;
	inputData.setInitialDeposit(deposit);

	cout << endl << "Monthly Deposit: $";
	cin >> monthly;
	inputData.setMonthlyDeposit(deposit);

	cout << endl << "Annual Interest: %";
	cin >> interest;
	inputData.setPercentInterest(interest);

	cout << endl << "Number of Years: ";
	cin >> years;
	inputData.setNumberYears(years);

	cout << endl <<"Press any key to continue . . ." << endl;
	return inputData;
}

int main() {
	char ch;

	do {
		InterestCalc inputData;
		inputData = InitialDisplay(inputData);

		ch = _getch();

		inputData.showReport(0);
		cout << endl << endl;
		inputData.showReport(inputData.getMonthlyDeposit());

		ch = _getch();

	} while (ch != NULL);
}
